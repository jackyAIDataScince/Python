# PythonCV
Python OpenCV

Reference:

https://dzone.com/articles/face-detection-using-python-and-opencv
Https://github.com/opencv/opencv

OpenCV - It also can be used to save vidoe files, such as, MP4,AVI and others.

https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_gui/py_video_display/py_video_display.html
